import React from 'react';

const Header = (props) => { 

    return (
        <div>
            <h1>Weather App</h1>
            <h3>Find weather conditions in your city</h3>
        </div>

    );
}

export default Header;